package com.crewmeister.cmcodingchallenge.currency;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.pivovarit.collectors.ParallelCollectors;

@Service
public class CurrencyService {

	@Autowired
	RestTemplate restTemplate;

	@Value("${url}")
	String url;

	@Value("${currencies}")
	String currencies;
	
	Logger logger = LoggerFactory.getLogger(CurrencyService.class);

	public List<CurrencyConversionRates> getAllCurrencyConversionRates() {

		ExecutorService executor = Executors.newFixedThreadPool(10);

		String[] currencyArray = currencies.split(",");

		return Arrays.asList(currencyArray).stream()
				.collect(ParallelCollectors.parallelToList(e -> downloadCurrencyConversionRates(e, null), executor, 5))
				.join();
	}

	public List<CurrencyConversionRates> getDateCurrencyConversionRates(String date) {

		ExecutorService executor = Executors.newFixedThreadPool(10);

		String[] currencyArray = currencies.split(",");

		return Arrays.asList(currencyArray).stream()
				.collect(ParallelCollectors.parallelToList(e -> downloadCurrencyConversionRates(e, date), executor, 5))
				.join();
	}

	public ConvertionRate getExchangerate(String currency, String date, Double amount) {

		CurrencyConversionRates currencyConversionRates = downloadCurrencyConversionRates(currency, date);

		CurrencyConversionRate currencyConversionRate = currencyConversionRates.getConversionRate().get(0);

		return new ConvertionRate(currency, currencyConversionRate.getConversionRate(),
				currencyConversionRate.getConversionRate() * amount);
	}

	private CurrencyConversionRates downloadCurrencyConversionRates(String currency, String date) {
		CurrencyConversionRates currencyList = null;
		String tmpUrl = url;
		byte[] fileBytes = restTemplate.getForObject(String.format(tmpUrl, currency), byte[].class);
		Path path = Paths.get(currency + System.currentTimeMillis() + ".csv");
		try {
			Files.write(path, fileBytes); 
		if (date != null)
			currencyList = new CurrencyConversionRates(getCurrencyList(path, date), currency);
		else
			currencyList = new CurrencyConversionRates(getCurrencyList(path), currency);

		Files.delete(path);
		}catch (Exception e) {
			logger.error("Error downloadCurrencyConversionRates currency:  {} -- Error : {}",currency,e);
		}
		return currencyList;

	}

	private List<CurrencyConversionRate> getCurrencyList(Path path) {

		List<CurrencyConversionRate> currencyList = new ArrayList<>();
		Scanner scanner = null;
		try {
			scanner = new Scanner(path);
			scanner.nextLine();
			int i = 0;
			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				if (i > 8 && !line.startsWith("\"")) {
					String[] array = line.split("\\,");
					if (!array[1].equalsIgnoreCase(".")) {
						currencyList.add(new CurrencyConversionRate(Double.parseDouble(array[1]), array[0]));
					}
				}

				i++;
			}

		} catch (Exception e) {
			logger.error("Error getCurrencyList error : {}",path.getFileName());
		} finally {
			if (scanner != null)
				scanner.close();
		}
		return currencyList;
	}

	private List<CurrencyConversionRate> getCurrencyList(Path path, String date) {

		List<CurrencyConversionRate> currencyList = new ArrayList<>();
		Scanner scanner = null;
		try {
			scanner = new Scanner(path);
			scanner.nextLine();
			int i = 0;
			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				if (i > 8 && !line.startsWith("\"")) {
					String[] array = line.split("\\,");
					if (!array[1].equalsIgnoreCase(".") && array[0].equalsIgnoreCase(date)) {
						currencyList.add(new CurrencyConversionRate(Double.parseDouble(array[1]), array[0]));
						break;
					}
				}

				i++;
			}

		} catch (Exception e) {
			logger.error("Error getCurrencyList error : {}",e);
		} finally {
			if (scanner != null)
				scanner.close();
		}
		return currencyList;
	}

	public List<String> getCurrencies() {
		
		String[] currencyArray = currencies.split(",");
		
		return Arrays.asList(currencyArray);
	}

}
