package com.crewmeister.cmcodingchallenge.currency;

import java.time.LocalDate;

public class CurrencyConversionRate {
	
    private double conversionRate;
    private LocalDate date;

    public CurrencyConversionRate(double conversionRate, String date) {
        this.conversionRate = conversionRate;
        this.date = LocalDate.parse(date);
    }

	public double getConversionRate() {
		return conversionRate;
	}

	public LocalDate getDate() {
		return date;
	}
    
}
