package com.crewmeister.cmcodingchallenge.currency;

public class ConvertionRate {

	private String currency;
	private Double currencyConvertionRate;
	private Double convertedAmount;
	
	
	public ConvertionRate(String currency, Double currencyConvertionRate, Double convertedAmount) {
		super();
		this.currency = currency;
		this.currencyConvertionRate = currencyConvertionRate;
		this.convertedAmount = convertedAmount;
	}

	public String getCurrency() {
		return currency;
	}
	
	public Double getCurrencyConvertionRate() {
		return currencyConvertionRate;
	}
	
	public Double getConvertedAmount() {
		return convertedAmount;
	}

	
	
}
