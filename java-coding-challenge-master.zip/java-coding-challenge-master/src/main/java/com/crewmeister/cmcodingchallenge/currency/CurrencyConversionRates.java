package com.crewmeister.cmcodingchallenge.currency;

import java.util.List;

public class CurrencyConversionRates {

	private List<CurrencyConversionRate> conversionRate;
	private String currency;
	
	public CurrencyConversionRates(List<CurrencyConversionRate> conversionRate, String currency) {
		this.conversionRate = conversionRate;
		this.currency = currency;
	}

	public List<CurrencyConversionRate> getConversionRate() {
		return conversionRate;
	}

	public String getCurrency() {
		return currency;
	}
		
}
