package com.crewmeister.cmcodingchallenge.currency;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController()
@RequestMapping("/api")
public class CurrencyController {
	
	@Autowired
	CurrencyService currencyService;

    @GetMapping("/currencies/EUR")
    public ResponseEntity<List<CurrencyConversionRates>> getAvailableCurrencies() {

    	List<CurrencyConversionRates> currencyConversionRates = currencyService.getAllCurrencyConversionRates();

        return new ResponseEntity<>(currencyConversionRates, HttpStatus.OK);
    }
    
    @GetMapping("/currencies/EUR/{date}")
    public ResponseEntity<List<CurrencyConversionRates>> getCurrencyByDate(@PathVariable String date) {

    	List<CurrencyConversionRates> currencyConversionRates = currencyService.getDateCurrencyConversionRates(date);

        return new ResponseEntity<>(currencyConversionRates, HttpStatus.OK);
    }
    
    @GetMapping("/currencies/EUR/{exchangeCurrency}/{date}/{amount}")
    public ResponseEntity<ConvertionRate> getCurrencyExchangeRate(@PathVariable String exchangeCurrency, @PathVariable String date, @PathVariable Double amount) {

    	ConvertionRate convertionRate = currencyService.getExchangerate(exchangeCurrency, date, amount);

        return new ResponseEntity<>(convertionRate, HttpStatus.OK);
    }
    
    @GetMapping("/currencies")
    public ResponseEntity<List<String>> getCurrencies() {

    	List<String> currencies = currencyService.getCurrencies();

        return new ResponseEntity<>(currencies, HttpStatus.OK);
    }
    
}
